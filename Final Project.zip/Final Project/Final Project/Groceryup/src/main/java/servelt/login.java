package servelt;


import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.cfg.Configuration;

import Entity.userdetails;


/**
 * Servlet implementation class logind
 */
public class login extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void service(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		RequestDispatcher rs;
		
		Configuration cfg = new Configuration();
		Session S = cfg.configure("connect.cfg.xml").buildSessionFactory().openSession();
		
		S.getTransaction().begin();
		
		
		
		String user =request.getParameter("username");
		String pwd =request.getParameter("password");
		userdetails u = null;
		int flag=0;
		Query qry =S.createQuery("from userdetails u where u.user_Id=:VAL"); // named parameter
		 
		  qry.setParameter("VAL", user);
		  
			List L = qry.list();
			
			Iterator it = L.iterator();
			while(it.hasNext())
				{
				u = (userdetails)it.next();
				flag = 1;	
				break;
				}

			if(flag == 1 && u.getPassword().equals(pwd))
			{
				rs = request.getServletContext().getRequestDispatcher("/index1.jsp");
								
				request.setAttribute("user",u.getName());
				request.setAttribute("pic", u.getPic());

								
			}
			else
			{
				
				request.setAttribute("name","signup");
				request.setAttribute("pic", "login");
				rs = request.getServletContext().getRequestDispatcher("/index.jsp");		
			}
			
			
			rs.forward(request, response);
			  	
			S.close();
			//F.close();
		
		
		
	}

	
	

}